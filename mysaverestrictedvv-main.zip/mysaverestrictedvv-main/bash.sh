echo "starting Bot ~@save_restricted";
python3 -m main
